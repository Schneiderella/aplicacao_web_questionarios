<?php
interface UsuarioDao {

    public function insere($usuario);
    public function remove($usuario);
    public function removePorId($id_usuario);
    public function altera(&$usuario);
    public function buscaPorId($id_usuario);
    public function buscaPorLogin($login);
    public function buscaTodos();
}
?>