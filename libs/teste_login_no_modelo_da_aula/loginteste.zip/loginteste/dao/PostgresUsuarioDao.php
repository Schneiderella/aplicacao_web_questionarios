<?php

include_once('UsuarioDao.php');
include_once('PostgresDao.php');

class PostgresUsuarioDao extends PostgresDao implements UsuarioDao {

    private $table_name = 'usuario';
    
    public function insere($usuario) {

        $query = "INSERT INTO " . $this->table_name . 
        " (login, senha, nome) VALUES" .
        " (:login, :senha, :nome)";

        $stmt = $this->conn->prepare($query);

        // bind values 
        $temp_login = ($usuario->getLogin());
        $temp_senha = md5($usuario->getSenha());
        $temp_nome = ($usuario->getNome());

        $stmt->bindParam(":login", $temp_login);
        $stmt->bindParam(":senha", $temp_senha);
        $stmt->bindParam(":nome", $temp_nome);

        if($stmt->execute()){
            return true;
        }else{
            return false;
        }

    }

    public function removePorId($id_usuario) {
        $query = "DELETE FROM " . $this->table_name . 
        " WHERE id_usuario = :id_usuario";

        $stmt = $this->conn->prepare($query);

        // bind parameters
        $stmt->bindParam(':id_usuario', $id_usuario);

        // execute the query
        if($stmt->execute()){
            return true;
        }    

        return false;
    }

    public function remove($usuario) {
        return removePorId($usuario->getId());
    }

    public function altera(&$usuario) {

        $query = "UPDATE " . $this->table_name . 
        " SET login = :login, senha = :senha, nome = :nome" .
        " WHERE id_usuario = :id_usuario";

        $stmt = $this->conn->prepare($query);

        // bind parameters
        $stmt->bindParam(":login", $usuario->getLogin());
        $stmt->bindParam(":senha", md5($usuario->getSenha()));
        $stmt->bindParam(":nome", $usuario->getNome());
        $stmt->bindParam(':id_usuario', $usuario->getId());

        // execute the query
        if($stmt->execute()){
            return true;
        }    

        return false;
    }

    public function buscaPorId($id_usuario) {
        
        $usuario = null;

        $query = "SELECT
                    id_usuario, login, nome, senha
                FROM
                    " . $this->table_name . "
                WHERE
                    id_usuario = ?
                LIMIT
                    1 OFFSET 0";
     
        $stmt = $this->conn->prepare( $query );
        $stmt->bindParam(1, $id_usuario);
        $stmt->execute();
     
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if($row) {
            $usuario = new Usuario($row['id_usuario'],$row['login'], $row['senha'], $row['nome']);
        } 
     
        return $usuario;
    }

    public function buscaPorLogin($login) {

        $usuario = null;

        $query = "SELECT
                    id_usuario, login, nome, senha
                FROM
                    " . $this->table_name . "
                WHERE
                    login = ?
                LIMIT
                    1 OFFSET 0";
     
        $stmt = $this->conn->prepare( $query );
        $stmt->bindParam(1, $login);
        $stmt->execute();
     
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if($row) {
            $usuario = new Usuario($row['id_usuario'],$row['login'], $row['senha'], $row['nome']);
        } 
     
        return $usuario;
    }

    /*
    public function buscaTodos() {

        $query = "SELECT
                    id_usuario, login, senha, nome
                FROM
                    " . $this->table_name . 
                    " ORDER BY id_usuario ASC";
     
        $stmt = $this->conn->prepare( $query );
        $stmt->execute();
     
        return $stmt;
    }
    */

    public function buscaTodos() {

        $usuarios = array();

        $query = "SELECT
                    id_usuario, login, senha, nome
                FROM
                    " . $this->table_name . 
                    " ORDER BY id_usuario ASC";
     
        $stmt = $this->conn->prepare( $query );
        $stmt->execute();

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $usuarios[] = new Usuario($id_usuario,$login,$senha,$nome);
        }
        
        return $usuarios;
    }
}
?>