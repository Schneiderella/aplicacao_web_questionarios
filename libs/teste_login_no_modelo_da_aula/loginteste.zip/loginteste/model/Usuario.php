<?php
class Usuario {
    
    private $id_usuario;
    private $login;
    private $senha;
    private $nome;

    public function __construct( $id_usuario, $login, $senha, $nome)
    {
        $this->id_usuario=$id_usuario;
        $this->login=$login;
        $this->senha=$senha;
        $this->nome=$nome;
    }

    public function getId() { return $this->id_usuario; }
    public function setId($id_usuario) {$this->id_usuario = $id_usuario;}

    public function getLogin() { return $this->login; }
    public function setLogin($login) {$this->login = $login;}

    public function getNome() { return $this->nome; }
    public function setNome($nome) {$this->nome = $nome;}

    public function getSenha() { return $this->senha; }
    public function setSenha($senha) {$this->senha = $senha;}
}
?>