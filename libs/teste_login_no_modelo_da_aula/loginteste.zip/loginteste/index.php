<?php
$page_title = "Testando login";
// layout do cabeçalho
include_once "layout_header.php";
?>
	<section>
	<nav>
		<ul>
			<li>Item do menu</li>
		</ul>
	</nav>		
		<article>
			<h2>Título do artigo 1</h2>
			<p>Conteúdo do artigo.</p>
		</article>
		
		<article>
			<h2>Título do artigo 2</h2>
			<p>Conteúdo do artigo.</p>
		</article>
		
	</section>
<?php
// layout do rodapé
include_once "layout_footer.php";
?>


