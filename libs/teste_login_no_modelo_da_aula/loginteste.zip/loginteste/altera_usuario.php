<?php
include_once "fachada.php";

$id = @$_GET["id_usuario"];
$login = @$_GET["login"];
$senha = @$_GET["senha"];
$nome = @$_GET["nome"];

$usuario = new Usuario($id_usuario,$login,$senha,$nome);
$dao = $factory->getUsuarioDao();

//$usuario->setPassword(md5($usuario->getPassword()));

$dao->altera($usuario);

header("Location: usuarios.php");
exit;

?>