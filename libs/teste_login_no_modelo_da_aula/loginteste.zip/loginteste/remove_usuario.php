<?php
include_once "fachada.php";

$id_usuario = @$_GET["id_usuario"];

$usuario = new Usuario($id_usuario,$login,$senha,$nome);
$dao = $factory->getUsuarioDao();
$dao->removePorId($id_usuario);

header("Location: usuarios.php");
exit;

?>